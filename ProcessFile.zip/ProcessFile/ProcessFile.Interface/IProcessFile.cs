﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessFile.Interface
{
    public interface IProcessFile
    {
        List<Student> LoadFile();

        void SaveStudentName(Dictionary<string, int> studentDic, IEnumerable<IGrouping<string, Student>> list);

        List<KeyValuePair<string, int>> SortFrequencyOfFirstAndLastName(Dictionary<string, int> studentDic);

        List<string> SortStudentAddress(List<Student> students);

        void CreateStudentNameTextFile(List<KeyValuePair<string, int>> sortedStudentList);

        void CreateStudentAddressTextFile(List<string> studentAddress);
    }
}
