﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using ProcessFile.Interface;
using ProcessFile.Common;
using Model;
using System.Collections.Generic;
using FakeItEasy;
using System.Linq;
using System.Collections;
using System.IO;

namespace ProcessFileUnitTest
{
    [TestClass]
    public class ProcessFileTest
    {
        private IProcessFile _processFileService;
        private IServiceFactory _serviceFactory;
        string pathOutPut_NAME = AppDomain.CurrentDomain.BaseDirectory + @"\OutPutFiles\StudentName.txt";
        string pathOutPut_ADDRESS = AppDomain.CurrentDomain.BaseDirectory + @"\OutPutFiles\StudentAddress.txt";

        [TestInitialize]
        public void TestSetUp()
        {
            _serviceFactory = Activator.CreateInstance<ServiceFactory>();
            _processFileService = _serviceFactory.GetInstance<ProcessCsvFile>();

            OnDeleteFileIfExist(pathOutPut_NAME);
            OnDeleteFileIfExist(pathOutPut_ADDRESS);
        }       

        [TestMethod]
        public void LoadedFile_Method_ShouldSuccessFullyLoadedFile()
        {
            var students = _processFileService.LoadFile();
            Assert.IsTrue(students != null);
        }

        [TestMethod]
        public void LoadedFile_Method_ShouldLoadedTheExactNumberOfStudentsInTheFile()
        {
            var expectedStudentNumber = 4;
            var students = _processFileService.LoadFile();
            Assert.AreEqual(expectedStudentNumber, students.Count);
        }

        [TestMethod]
        public void SaveSortedItem_Method_ShouldSaveStudentFirstNameAndLastNameOnaLocalCollectionAndTestDifferentScenarios()
        {
            var studentDic = new Dictionary<string, int>();
            var students = GetStudent();

            Assert.IsFalse(studentDic.Count > 0);

            _processFileService.SaveStudentName(studentDic, students.GroupBy(s => s.FirstName));

            Assert.IsTrue(studentDic.Count > 0);
            //Checking for a name that doesn't exist in the lastname column
            Assert.IsTrue(studentDic.ContainsKey(students.FirstOrDefault(s => s.FirstName == "oliver").FirstName));
            Assert.IsFalse(studentDic.ContainsKey("dlamini"));

            _processFileService.SaveStudentName(studentDic, students.GroupBy(s => s.LastName));
            //Checking for the lastname that doesn't exist in the firstname column
            Assert.IsTrue(studentDic.ContainsKey("dlamini"));
        }

        [TestMethod]
        public void SortFrequencyOfFirstAndLastName_Method_ShouldTestSortedStudentFirstAndLastNameMergedInOneList()
        {
            var studentDic = new Dictionary<string, int>();
            var students = GetStudent();
            var expectedResult = GetStudentDic();

            _processFileService.SaveStudentName(studentDic, students.GroupBy(s => s.FirstName));
            _processFileService.SaveStudentName(studentDic, students.GroupBy(s => s.LastName));

            var actualResult = _processFileService.SortFrequencyOfFirstAndLastName(studentDic);            

            CollectionAssert.AreEqual((expectedResult as ICollection), (actualResult as ICollection));            
        }




        [TestMethod]
        public void SortStudentAddress_Method_ShouldTestWhetherOrNotTheStudentAddressHasbeenSorted()
        {
            var students = GetStudent();

            var expectedResult = SortedStudentAddress();

            var studentAddresses = students.Select(s => (new { s.Address }).ToString()).ToList();

            Assert.AreNotEqual(expectedResult, studentAddresses);

            var actualResult = _processFileService.SortStudentAddress(students);

            Assert.AreNotEqual(expectedResult, actualResult);
        }


        [TestMethod]
        public void CreateStudentNameTextFile_Method_ShouldTestWhetherOrNotTheStudentNameFileHasbeenCreated()
        {
            var sortedStudents = GetStudentDic();

            Assert.IsFalse(File.Exists(pathOutPut_NAME));

            _processFileService.CreateStudentNameTextFile(sortedStudents);

            Assert.IsTrue(File.Exists(pathOutPut_NAME));

            var studentNames = File.ReadAllLines(pathOutPut_NAME);

            Assert.IsNotNull(studentNames);
        }        
        [TestMethod]
        public void CreateStudentAddressTextFile_Method_ShouldTestWhetherOrNotTheStudentAddressFileHasbeenCreated()
        {
            var students = GetStudent();

            var sortedStudentAddress = _processFileService.SortStudentAddress(students);

            Assert.IsFalse(File.Exists(pathOutPut_ADDRESS));

            _processFileService.CreateStudentAddressTextFile(sortedStudentAddress);

            Assert.IsTrue(File.Exists(pathOutPut_ADDRESS));

            var studentAddress = File.ReadAllLines(pathOutPut_ADDRESS);

            Assert.IsNotNull(studentAddress);
        }       

        private List<Student> GetStudent()
        {
            return new List<Student>()
            {
                new Student() { FirstName="oliver", LastName="kabongo", Address="23 Queens Av" },
                new Student() { FirstName="junior", LastName="dlamini", Address="10 Bekker st" },
                new Student() { FirstName="kabongo", LastName="junior", Address="35 Long st" }
            };
        }       

        private List<KeyValuePair<string, int>> GetStudentDic()
        {
            var studentDic = new Dictionary<string, int>();
            studentDic.Add("junior", 2);
            studentDic.Add("kabongo", 2);            
            studentDic.Add("dlamini", 1);
            studentDic.Add("oliver", 1);

            return studentDic.ToList();
        }

        private List<string> SortedStudentAddress()
        {
            return new List<string>()
            {
                "10 Bekker st",
                "35 Long st",
                "23 Queens Av"
            };
        }
        private void OnDeleteFileIfExist(string path)
        {
            if (File.Exists(path))
                File.Delete(path);
        }
    }    
}
