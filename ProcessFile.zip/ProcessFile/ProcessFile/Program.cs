﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Model;
using System.Text.RegularExpressions;
using System.Collections;
using ProcessFile.Common;
using ProcessFile.Interface;
using System.ComponentModel.Composition;

namespace ProcessFile
{
    public class Program 
    {
        static Dictionary<string, int> _studentDic = new Dictionary<string, int>();
        static IProcessFile _processFileService = Activator.CreateInstance<ServiceFactory>().GetInstance<ProcessCsvFile>();        
        static void Main(string[] args)
        {

            var students = _processFileService.LoadFile();
            var studentsFirstNames = students.GroupBy(x => x.FirstName);
            var studentsLastNames = students.GroupBy(i => i.LastName);

            _processFileService.SaveStudentName(_studentDic, studentsFirstNames);
            _processFileService.SaveStudentName(_studentDic, studentsLastNames);

            var sortedStudentNames = _processFileService.SortFrequencyOfFirstAndLastName(_studentDic);

            var sortedStudentAddresses = _processFileService.SortStudentAddress(students);

            _processFileService.CreateStudentNameTextFile(sortedStudentNames);

            _processFileService.CreateStudentAddressTextFile(sortedStudentAddresses);
        }
    } 

}
