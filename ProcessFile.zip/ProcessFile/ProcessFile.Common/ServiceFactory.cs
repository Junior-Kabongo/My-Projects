﻿using ProcessFile.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProcessFile.Common
{
    public class ServiceFactory : IServiceFactory
    {
        public T GetInstance<T>() where T : class
        {
            return Activator.CreateInstance<T>();
        }
        
    }
}
