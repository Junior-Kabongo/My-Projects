﻿using Model;
using ProcessFile.Interface;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ProcessFile.Common
{   
    public class ProcessCsvFile : IProcessFile
    {       
        string path = AppDomain.CurrentDomain.BaseDirectory + @"\InPutFile\data.csv";
        string pathOutPut_NAME = AppDomain.CurrentDomain.BaseDirectory + @"\OutPutFiles\StudentName.txt";
        string pathOutPut_ADDRESS = AppDomain.CurrentDomain.BaseDirectory + @"\OutPutFiles\StudentAddress.txt";
                
        public ProcessCsvFile()
        {
        }
        public List<Student> LoadFile()
        {
            var values = File.ReadAllLines(path);

            return (from value in values.Skip(1)
                    let data = value.Split(',')
                    select new Student()
                    {
                        FirstName = data[0],
                        LastName = data[1],
                        Address = data[2],
                        PhoneNumber = data[3]
                    }).ToList();
        }
        public void SaveStudentName(Dictionary<string, int> studentDic, IEnumerable<IGrouping<string, Student>> list)
        {
            foreach (var item in list)
            {
                if (!studentDic.ContainsKey(item.Key))
                    studentDic.Add(item.Key, item.Count());
                else
                    studentDic[item.Key] += item.Count();
            }
        }
        public List<KeyValuePair<string, int>> SortFrequencyOfFirstAndLastName(Dictionary<string, int> studentDic)
        {
            return studentDic.OrderByDescending(s => s.Value).ThenBy(s => s.Key).ToList();
        }

        public List<string> SortStudentAddress(List<Student> students)
        {
            var filteredAddresses = students.Select(s => s.Address).ToList();

            return filteredAddresses.Select(s => new { fullAddress = s, splitedAddress = s.Split(' ') })
                                    .OrderBy(x => x.splitedAddress[1])
                                    .Select(x => x.fullAddress)
                                    .ToList();
        }
        public void CreateStudentAddressTextFile(List<string> studentAddress)
        {
            if (!File.Exists(pathOutPut_ADDRESS))
            {
                using (StreamWriter fileStream = File.CreateText(pathOutPut_ADDRESS))
                {
                    studentAddress.ForEach(address =>
                    {
                        fileStream.WriteLine(address);
                    });
                }
            }
            else
            {
                using (var fileStream = new StreamWriter(pathOutPut_ADDRESS, true))
                {
                    studentAddress.ForEach(address =>
                    {
                        fileStream.WriteLine(address);
                    });
                }
            }
        } 
        public void CreateStudentNameTextFile(List<KeyValuePair<string, int>> sortedStudentList)
        {
            if (!File.Exists(pathOutPut_NAME))
            {
                using (StreamWriter fileStream = File.CreateText(pathOutPut_NAME))
                {
                    sortedStudentList.ForEach(student =>
                    {
                        fileStream.WriteLine(
                            string.Format(CultureInfo.CurrentCulture,"{0} {1}", student.Key,student.Value));
                    });
                }
            }
            else
            {
                using (var fileStream = new StreamWriter(pathOutPut_NAME, true))
                {
                    sortedStudentList.ForEach(student =>
                    {
                        fileStream.WriteLine(
                            string.Format(CultureInfo.CurrentCulture, "{0} {1}", student.Key, student.Value));
                    });
                }
            }
        }
    }
}
